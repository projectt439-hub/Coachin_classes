// Course data
const courses = {
    sql: {
        title: "SQL Database Course",
        content: `
            <p>Master SQL from basics to advanced concepts!</p>
            <h3>What You'll Learn:</h3>
            <ul>
                <li>Database Fundamentals</li>
                <li>SQL Queries & Commands</li>
                <li>Data Manipulation</li>
                <li>Database Design</li>
            </ul>
            <p>Topics: <button onclick="showTopic('sql_basics')">Basics</button> <button onclick="showTopic('sql_queries')">Queries</button> <button onclick="showTopic('sql_design')">Design</button></p>
            <div id="topic-content"></div>
        `
    },
    postgres: {
        title: "PostgreSQL Advanced Course",
        content: `
            <p>Become a PostgreSQL expert!</p>
            <h3>Course Content:</h3>
            <ul>
                <li>PostgreSQL Installation & Setup</li>
                <li>Advanced SQL Features</li>
                <li>Performance Optimization</li>
                <li>Database Administration</li>
            </ul>
            <p>Topics: <button onclick="showTopic('postgres_setup')">Setup</button> <button onclick="showTopic('postgres_advanced')">Advanced</button> <button onclick="showTopic('postgres_admin')">Admin</button></p>
            <div id="topic-content"></div>
        `
    },
    ai: {
        title: "Artificial Intelligence Course",
        content: `
            <p>Explore the world of AI!</p>
            <h3>Covered Topics:</h3>
            <ul>
                <li>AI Fundamentals</li>
                <li>Neural Networks</li>
                <li>Natural Language Processing</li>
                <li>Computer Vision</li>
            </ul>
            <p>Topics: <button onclick="showTopic('ai_fundamentals')">Fundamentals</button> <button onclick="showTopic('ai_neural')">Neural Networks</button> <button onclick="showTopic('ai_nlp')">NLP</button></p>
            <div id="topic-content"></div>
        `
    },
    ml: {
        title: "Machine Learning Course",
        content: `
            <p>Hands-on Machine Learning!</p>
            <h3>Learning Path:</h3>
            <ul>
                <li>Python for Data Science</li>
                <li>Supervised Learning</li>
                <li>Unsupervised Learning</li>
                <li>Model Deployment</li>
            </ul>
            <p>Topics: <button onclick="showTopic('ml_python')">Python</button> <button onclick="showTopic('ml_supervised')">Supervised</button> <button onclick="showTopic('ml_deployment')">Deployment</button></p>
            <div id="topic-content"></div>
        `
    },
    java: {
        title: "Java Programming Course",
        content: `
            <p>Complete Java mastery!</p>
            <h3>Course Structure:</h3>
            <ul>
                <li>Java Fundamentals</li>
                <li>Object-Oriented Programming</li>
                <li>Advanced Java</li>
                <li>Web Development with Java</li>
            </ul>
            <p>Topics: <button onclick="showTopic('java_fundamentals')">Fundamentals</button> <button onclick="showTopic('java_oop')">OOP</button> <button onclick="showTopic('java_web')">Web Dev</button></p>
            <div id="topic-content"></div>
        `
    },
    python: {
        title: "Python Programming Course",
        content: `
            <p>Python for everyone!</p>
            <h3>What You'll Build:</h3>
            <ul>
                <li>Python Basics</li>
                <li>Data Structures & Algorithms</li>
                <li>Web Applications</li>
                <li>Automation Scripts</li>
            </ul>
            <p>Topics: <button onclick="showTopic('py_basics')">Basics</button> <button onclick="showTopic('py_data')">Data Structures</button> <button onclick="showTopic('py_web')">Web Apps</button></p>
            <div id="topic-content"></div>
        `
    }
};

// Function to show course details
function showCourse(courseKey) {
    const course = courses[courseKey];
    if (!course) return;
    const courseTitle = document.getElementById('course-title');
    const courseContent = document.getElementById('course-content');
    const coursesSection = document.getElementById('courses');
    const courseDetails = document.getElementById('course-details');

    if (courseTitle) courseTitle.textContent = course.title;
    if (courseContent) courseContent.innerHTML = course.content;
    if (coursesSection) coursesSection.style.display = 'none';
    if (courseDetails) courseDetails.style.display = 'block';
}

// Function to show topic content
function showTopic(topic) {
    const topics = {
        sql_basics: "<p>SQL Basics: Learn SELECT, INSERT, UPDATE, DELETE and basic database operations.</p><p>Example: SELECT * FROM users WHERE age > 18;</p>",
        sql_queries: "<p>Advanced Queries: JOINs, subqueries, aggregations, and complex SQL operations.</p><p>Example: SELECT u.name, COUNT(o.id) FROM users u LEFT JOIN orders o ON u.id = o.user_id GROUP BY u.id;</p>",
        sql_design: "<p>Database Design: Normalization, relationships, indexes, and optimization techniques.</p><p>Key concepts: primary keys, foreign keys, and data integrity.</p>",
        postgres_setup: "<p>PostgreSQL Setup: Installation, configuration, and basic administration.</p><p>Commands: CREATE DATABASE, CREATE USER, GRANT permissions.</p>",
        postgres_advanced: "<p>Advanced PostgreSQL: JSON support, full-text search, window functions, and extensions.</p><p>Example: SELECT json_column->>'name' FROM table_name;</p>",
        postgres_admin: "<p>Database Administration: Backup, recovery, monitoring, and performance tuning.</p><p>Tools: pg_dump, pg_restore, EXPLAIN ANALYZE.</p>",
        ai_fundamentals: "<p>AI Fundamentals: What is AI, history, and current applications.</p><p>Key areas: machine learning, deep learning, and intelligent systems.</p>",
        ai_neural: "<p>Neural Networks: Architecture, training, backpropagation, and activation functions.</p><p>Types: feedforward, convolutional, recurrent networks.</p>",
        ai_nlp: "<p>Natural Language Processing: Text processing, sentiment analysis, and language models.</p><p>Technologies: BERT, GPT, spaCy, NLTK.</p>",
        ml_python: "<p>ML Python: NumPy, Pandas, Matplotlib, and Scikit-learn basics.</p><p>Example: import pandas as pd; df = pd.read_csv('data.csv')</p>",
        ml_supervised: "<p>Supervised Learning: Regression and classification algorithms.</p><p>Algorithms: linear regression, decision trees, SVM, neural networks.</p>",
        ml_deployment: "<p>Model Deployment: Flask/Django APIs, cloud deployment, and monitoring.</p><p>Tools: Docker, Kubernetes, AWS SageMaker.</p>",
        java_fundamentals: "<p>Java Fundamentals: Variables, data types, control structures, and methods.</p><p>Syntax: public static void main(String[] args) { }</p>",
        java_oop: "<p>Object-Oriented Programming: Classes, objects, inheritance, and polymorphism.</p><p>Principles: encapsulation, abstraction, inheritance, polymorphism.</p>",
        java_web: "<p>Java Web Development: Servlets, JSP, Spring, and REST APIs.</p><p>Frameworks: Spring Boot, Hibernate, Maven.</p>",
        py_basics: "<p>Python Basics: Variables, loops, functions, and file handling.</p><p>Syntax: def hello(): print('Hello World')</p>",
        py_data: "<p>Data Structures: Lists, tuples, dictionaries, sets, and algorithms.</p><p>Example: my_list = [1, 2, 3]; my_dict = {'key': 'value'}</p>",
        py_web: "<p>Web Development: Flask/Django, HTML templates, and databases.</p><p>Example: from flask import Flask; app = Flask(__name__)</p>"
    };
    const content = document.getElementById('topic-content');
    if (content) content.innerHTML = topics[topic] || "<p>Topic content coming soon!</p>";
}

// Utility helper
function safeGet(id) {
    return document.getElementById(id);
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.view-course').forEach(button => {
        button.addEventListener('click', function() {
            const courseKey = this.parentElement.getAttribute('data-course');
            showCourse(courseKey);
        });
    });

    const backBtn = safeGet('back-btn');
    if (backBtn) {
        backBtn.addEventListener('click', function() {
            const courseDetails = safeGet('course-details');
            const coursesSection = safeGet('courses');
            if (courseDetails) courseDetails.style.display = 'none';
            if (coursesSection) coursesSection.style.display = 'block';
        });
    }

    const enrollBtn = safeGet('enrollBtn');
    if (enrollBtn) {
        enrollBtn.addEventListener('click', function() {
            alert('Thank you for your interest! Enrollment feature coming soon.');
        });
    }

    const contactForm = safeGet('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = safeGet('name')?.value || 'Student';
            alert(`Thank you ${name}! Your message has been sent.`);
            this.reset();
        });
    }

    const loginModal = safeGet('loginModal');
    const registerModal = safeGet('registerModal');
    const loginBtn = safeGet('loginBtn');
    const registerBtn = safeGet('registerBtn');
    const closeBtns = document.getElementsByClassName('close');

    if (loginBtn && loginModal) {
        loginBtn.onclick = function() {
            loginModal.style.display = 'block';
        };
    }
    if (registerBtn && registerModal) {
        registerBtn.onclick = function() {
            registerModal.style.display = 'block';
        };
    }

    for (let i = 0; i < closeBtns.length; i++) {
        const closeBtn = closeBtns[i];
        closeBtn.onclick = function() {
            if (loginModal) loginModal.style.display = 'none';
            if (registerModal) registerModal.style.display = 'none';
        };
    }

    window.onclick = function(event) {
        if (loginModal && event.target === loginModal) {
            loginModal.style.display = 'none';
        }
        if (registerModal && event.target === registerModal) {
            registerModal.style.display = 'none';
        }
    };

    const loginForm = safeGet('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = safeGet('loginEmail')?.value || '';
            const password = safeGet('loginPassword')?.value || '';
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const user = users.find(u => u.email === email && u.password === password);
            if (user) {
                localStorage.setItem('currentUser', JSON.stringify(user));
                showDashboard(user.name);
                if (loginModal) loginModal.style.display = 'none';
                alert('Login successful!');
            } else {
                alert('Invalid email or password');
            }
            this.reset();
        });
    }

    const registerForm = safeGet('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = safeGet('regName')?.value || '';
            const email = safeGet('regEmail')?.value || '';
            const password = safeGet('regPassword')?.value || '';
            const confirmPassword = safeGet('regConfirmPassword')?.value || '';
            if (password !== confirmPassword) {
                alert('Passwords do not match');
                return;
            }
            const users = JSON.parse(localStorage.getItem('users')) || [];
            if (users.find(u => u.email === email)) {
                alert('Email already registered');
                return;
            }
            const newUser = { name, email, password };
            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));
            alert('Registration successful! Please login.');
            if (registerModal) registerModal.style.display = 'none';
            this.reset();
        });
    }

    const logoutBtn = safeGet('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('currentUser');
            const dashboard = safeGet('dashboard');
            if (dashboard) dashboard.style.display = 'none';
            alert('Logged out successfully!');
        });
    }

    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        showDashboard(currentUser.name);
    }
});

// Function to show dashboard
function showDashboard(name) {
    const userName = safeGet('userName');
    const dashboard = safeGet('dashboard');
    if (userName) userName.textContent = name;
    if (dashboard) dashboard.style.display = 'block';
}